<p align="center">fHDHR_TEMPLATE    <img src="docs/images/logo.ico" alt="Logo"/></p>


Welcome to the world of streaming content as a DVR device! We use some fancy python here to achieve a system of:

**f**un
**H**ome
**D**istribution
**H**iatus
**R**ecreation


Please Check the [Docs](https://fhdhr.github.io/fHDHR_Template/) for Installation information.

fHDHR is labeled as beta until we reach v1.0.0

Join us in `#fHDHR <irc://irc.freenode.net/#fHDHR>`_ on Freenode.
