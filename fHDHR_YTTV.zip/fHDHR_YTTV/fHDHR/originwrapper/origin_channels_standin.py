

class OriginChannels_StandIN():
    def __init__(self):
        pass

    def get_channels(self):
        return []

    def get_channel_stream(self, chandict, stream_args):
        return None
