

class OriginEPG_StandIN():
    def __init__(self):
        pass

    def update_epg(self, channels):
        return {}
