

class OriginService():

    def __init__(self, fhdhr):
        self.fhdhr = fhdhr
