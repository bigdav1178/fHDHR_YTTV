

class OriginChannels():

    def __init__(self, fhdhr, origin):
        self.fhdhr = fhdhr
        self.origin = origin

    def get_channels(self):

        channel_list = []

        return channel_list

    def get_channel_stream(self, chandict, stream_args):
        streamurl = ""
        stream_info = {"url": streamurl}

        return stream_info
