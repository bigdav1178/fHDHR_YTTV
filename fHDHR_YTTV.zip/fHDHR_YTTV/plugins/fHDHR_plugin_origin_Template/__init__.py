PLUGIN_NAME = "Template"
PLUGIN_VERSION = "v0.6.0-beta"
PLUGIN_TYPE = "origin"


class TEMPLATE_Setup():
    def __init__(self, config):
        pass
