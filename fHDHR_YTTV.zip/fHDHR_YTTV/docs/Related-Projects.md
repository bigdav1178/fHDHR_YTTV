<p align="center">fHDHR    <img src="images/logo.ico" alt="Logo"/></p>

---
[Main](README.md)  |  [Setup and Usage](Usage.md)  |  [template](Origin.md)  |  [Credits/Related Projects](Related-Projects.md)
---
**f**un
**H**ome
**D**istribution
**H**iatus
**R**ecreation

---


While the fHDHR reops share very little code from the below projects, they were a source of inspiration:

  * [tvhProxy by jkaberg](https://github.com/jkaberg/tvhProxy)
  * [locast2plex by tgorgdotcom](https://github.com/tgorgdotcom/locast2plex)


Aside from the above, these other projects are worth a look as well:

* [npvrProxy](https://github.com/rogueosb/npvrProxy)
* [xTeVe](https://xteve.de/)
* [telly](https://github.com/tellytv/telly)
* [dizquetv](https://github.com/vexorian/dizquetv)
